<?php


    $conexion = new mysqli("ls-20c21c77c56c2d07648f7a1579f9a4a10b244a6a.cpefgjofumk0.us-east-2.rds.amazonaws.com","dbmasteruser","TiS>>qNh!`Uc;Et[o2W^gX5r}^r,00mi","bdcecyteq");

    if($conexion){
    } else {
      echo "efe";
    }

 ?>
